 
## Thanks for taking up Interest in contributing to collegexplorer.
Here are some guidelines which are to be followed in order to contribute to the repo.
 * clone the repository.
	git clone https://github.com/CollegExplorer/CollegeExplorer-web.git
 * Create a separate directory on your system, say collegexplorer.
 * For pushing changes, all commits have to be marked on 'bug-fix' branch.

